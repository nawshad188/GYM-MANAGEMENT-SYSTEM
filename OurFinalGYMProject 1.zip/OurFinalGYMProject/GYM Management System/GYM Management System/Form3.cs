﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GYM_Management_System
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        DBConnection db = new DBConnection();
        public int UserID;
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                UserID = Convert.ToInt32(row.Cells[0].Value);
                useridtxt.Text = UserID.ToString();
                nametxt.Text = row.Cells[1].Value.ToString();
                passwordtxt.Text = row.Cells[2].Value.ToString();
                emailtxt.Text = row.Cells[3].Value.ToString();
                string gender = row.Cells[4].Value.ToString();
                foreach (Control ctrl in panel1.Controls)
                {
                    if (ctrl is RadioButton rb)
                    {
                        rb.Checked = (rb.Text == gender);
                    }
                }
                packagetxt.Text = row.Cells[5].Value.ToString();
            }
            else
            {
                useridtxt.Clear();
                nametxt.Clear();
                passwordtxt.Clear();
                emailtxt.Clear();
                packagetxt.Clear();

            }

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            GetMembersInfo();
        }

        private void GetMembersInfo()
        {
            SqlConnection con = db.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Members", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridView1.DataSource=dt;


        }

        private void btwUpDate_Click(object sender, EventArgs e)
        {
            SqlConnection con = db.GetConnection();
            string gender = "";
            foreach (Control ctrl in panel1.Controls)
            {
                if (ctrl is RadioButton rb && rb.Checked)
                {
                    gender = rb.Text;
                    break;
                }
            }
            SqlCommand cmd = new SqlCommand(
                "UPDATE Members SET Name=@Name, Password=@Password, Email=@Email, Gender=@Gender, Package=@Package WHERE UserID=@UserID", con);

            cmd.Parameters.AddWithValue("@UserID", UserID);
            cmd.Parameters.AddWithValue("@Name", nametxt.Text);
            cmd.Parameters.AddWithValue("@Password", passwordtxt.Text);
            cmd.Parameters.AddWithValue("@Email", emailtxt.Text);
            cmd.Parameters.AddWithValue("@Gender", gender);
            cmd.Parameters.AddWithValue("@Package", packagetxt.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Member updated successfully!");
            GetMembersInfo();

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {

            SqlConnection con = db.GetConnection();
            SqlCommand cmd = new SqlCommand("DELETE FROM Members WHERE UserID=@UserID", con);
            cmd.Parameters.AddWithValue("@UserID", UserID);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Are you Sure you want to Remove this member");
            GetMembersInfo();
            useridtxt.Clear();
            nametxt.Clear();
            passwordtxt.Clear();
            emailtxt.Clear();
            packagetxt.Clear();

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            SqlConnection con = db.GetConnection();
            SqlCommand cmd = new SqlCommand(
                "SELECT * FROM Members WHERE Name LIKE @Search OR Email LIKE @Search", con);

            cmd.Parameters.AddWithValue("@Search", "%" + searchtxt.Text + "%");
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
            else
            {
                dataGridView1.DataSource = null;
                MessageBox.Show("Not Found");
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            SqlConnection con = db.GetConnection();
            string gender = "";
            foreach (Control ctrl in panel1.Controls)
            {
                if (ctrl is RadioButton rb && rb.Checked)
                {
                    gender = rb.Text;
                    break;
                }
            }
            if (string.IsNullOrWhiteSpace(nametxt.Text) ||
                string.IsNullOrWhiteSpace(passwordtxt.Text) ||
                string.IsNullOrWhiteSpace(emailtxt.Text) ||
                string.IsNullOrWhiteSpace(packagetxt.Text) ||
                string.IsNullOrWhiteSpace(gender))
            {
                MessageBox.Show("Please fill all fields and select gender.");
                return;
            }
            SqlCommand cmd = new SqlCommand(
                "INSERT INTO Members (Name, Password, Email, Gender, Package) " +
                "VALUES (@Name, @Password, @Email, @Gender, @Package); " +
                "SELECT SCOPE_IDENTITY();", con);

            cmd.Parameters.AddWithValue("@Name", nametxt.Text);
            cmd.Parameters.AddWithValue("@Password", passwordtxt.Text);
            cmd.Parameters.AddWithValue("@Email", emailtxt.Text);
            cmd.Parameters.AddWithValue("@Gender", gender);
            cmd.Parameters.AddWithValue("@Package", packagetxt.Text);
            con.Open();
            object newId = cmd.ExecuteScalar();
            con.Close();
            int userId = Convert.ToInt32(newId);
            useridtxt.Text = userId.ToString();
            MessageBox.Show("New member added successfully! UserID: " + userId);
            GetMembersInfo();
            useridtxt.Clear();
            nametxt.Clear();
            passwordtxt.Clear();
            emailtxt.Clear();
            packagetxt.Clear();


        }
    }
}
