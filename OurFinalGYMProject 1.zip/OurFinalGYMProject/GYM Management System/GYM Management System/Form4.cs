﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;


namespace GYM_Management_System
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }


        private void btnGetDetails_Click(object sender, EventArgs e)
        {
            if (txtSingUpUserId.Text == "")
            {
                MessageBox.Show("Please enter User ID");
                return;
            }

            DBConnection db = new DBConnection();
            SqlConnection con = db.GetConnection();

            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT Name,Email,Gender,Age,Package FROM dbo.Members  WHERE UserID = @uid", con);
            cmd.Parameters.Add("@uid", SqlDbType.Int).Value=int.Parse(txtSingUpUserId.Text);

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                txtSingUpName.Text = dr["Name"].ToString();
                txtSingUpEmail.Text = dr["Email"].ToString();
                txtSingUpAge.Text = dr["Age"].ToString();
                txtSingUpPackage.Text = dr["Package"].ToString();

                string gender = dr["Gender"].ToString();
                if (gender == "Male")
                    radioButtonMale.Checked = true;
                else if (gender == "Female")
                    radioButtonFemale.Checked = true;

            }
            else
            {
                MessageBox.Show("Invalid User Id");
                ClearFields();
            }
            dr.Close();
            con.Close();
        }

        void ClearFields()
        {
            txtSingUpName.Clear();
            txtSingUpEmail.Clear();
            txtSingUpAge.Clear();
            txtSingUpPackage.Clear();

            radioButtonMale.Checked = false;
            radioButtonFemale.Checked = false;

        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
           
            if (txtSingUpName.Text == "")
            {
                MessageBox.Show("Invalid Details");
                return;
            }

           
            Form5 paymentForm = new Form5(txtSingUpPackage.Text);
            paymentForm.Show();

           
            this.Hide();


        }
    }
}

