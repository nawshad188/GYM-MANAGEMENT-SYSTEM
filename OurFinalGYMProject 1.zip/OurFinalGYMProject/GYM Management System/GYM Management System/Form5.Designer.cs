﻿namespace GYM_Management_System
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPackage = new System.Windows.Forms.Label();
            this.labelAmount = new System.Windows.Forms.Label();
            this.txtPaymentPackage = new System.Windows.Forms.TextBox();
            this.txtPaymentAmount = new System.Windows.Forms.TextBox();
            this.radioCash = new System.Windows.Forms.RadioButton();
            this.radioCreditCard = new System.Windows.Forms.RadioButton();
            this.btnProceed = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelPackage
            // 
            this.labelPackage.AutoSize = true;
            this.labelPackage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPackage.Location = new System.Drawing.Point(181, 99);
            this.labelPackage.Name = "labelPackage";
            this.labelPackage.Size = new System.Drawing.Size(83, 20);
            this.labelPackage.TabIndex = 0;
            this.labelPackage.Text = "Package :";
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAmount.Location = new System.Drawing.Point(150, 147);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(114, 20);
            this.labelAmount.TabIndex = 1;
            this.labelAmount.Text = "Enter amount:";
            // 
            // txtPaymentPackage
            // 
            this.txtPaymentPackage.Location = new System.Drawing.Point(289, 97);
            this.txtPaymentPackage.Name = "txtPaymentPackage";
            this.txtPaymentPackage.ReadOnly = true;
            this.txtPaymentPackage.Size = new System.Drawing.Size(100, 22);
            this.txtPaymentPackage.TabIndex = 2;
            // 
            // txtPaymentAmount
            // 
            this.txtPaymentAmount.Location = new System.Drawing.Point(289, 147);
            this.txtPaymentAmount.Name = "txtPaymentAmount";
            this.txtPaymentAmount.Size = new System.Drawing.Size(100, 22);
            this.txtPaymentAmount.TabIndex = 3;
            this.txtPaymentAmount.TextChanged += new System.EventHandler(this.txtpaymentAmount_TextChanged);
            // 
            // radioCash
            // 
            this.radioCash.AutoSize = true;
            this.radioCash.Location = new System.Drawing.Point(289, 199);
            this.radioCash.Name = "radioCash";
            this.radioCash.Size = new System.Drawing.Size(59, 20);
            this.radioCash.TabIndex = 4;
            this.radioCash.TabStop = true;
            this.radioCash.Text = "Cash";
            this.radioCash.UseVisualStyleBackColor = true;
            // 
            // radioCreditCard
            // 
            this.radioCreditCard.AutoSize = true;
            this.radioCreditCard.Location = new System.Drawing.Point(383, 199);
            this.radioCreditCard.Name = "radioCreditCard";
            this.radioCreditCard.Size = new System.Drawing.Size(92, 20);
            this.radioCreditCard.TabIndex = 5;
            this.radioCreditCard.TabStop = true;
            this.radioCreditCard.Text = "CreditCard";
            this.radioCreditCard.UseVisualStyleBackColor = true;
            // 
            // btnProceed
            // 
            this.btnProceed.Location = new System.Drawing.Point(289, 302);
            this.btnProceed.Name = "btnProceed";
            this.btnProceed.Size = new System.Drawing.Size(75, 23);
            this.btnProceed.TabIndex = 6;
            this.btnProceed.Text = "  ";
            this.btnProceed.UseVisualStyleBackColor = true;
            this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnProceed);
            this.Controls.Add(this.radioCreditCard);
            this.Controls.Add(this.radioCash);
            this.Controls.Add(this.txtPaymentAmount);
            this.Controls.Add(this.txtPaymentPackage);
            this.Controls.Add(this.labelAmount);
            this.Controls.Add(this.labelPackage);
            this.Name = "Form5";
            this.Text = "PaymentPanel";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPackage;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.TextBox txtPaymentPackage;
        private System.Windows.Forms.TextBox txtPaymentAmount;
        private System.Windows.Forms.RadioButton radioCash;
        private System.Windows.Forms.RadioButton radioCreditCard;
        private System.Windows.Forms.Button btnProceed;
    }
}