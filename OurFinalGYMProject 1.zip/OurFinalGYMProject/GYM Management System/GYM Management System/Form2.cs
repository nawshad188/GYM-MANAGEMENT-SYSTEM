﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Mail;

namespace GYM_Management_System
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }


        private void btnReg_Click(object sender, EventArgs e)
        {
            DBConnection db = new DBConnection();
            SqlConnection con = db.GetConnection();
            con.Open();

            if (!IsValidEmail(txtSingUpEmail.Text))
            {
                MessageBox.Show("Invalid email format. Example: srleon512@gmail.com");
                return;
            }

            string gender = "";
            if (radioButtonMale.Checked)
                gender = "Male";
            else if (radiobuttonFemale.Checked)
                gender = "Female";
            else
            {
                MessageBox.Show("Please select gender.");
                return; 
            }


            SqlCommand cmd = new SqlCommand("INSERT INTO Members(Name,Password,Email,Gender,Age,Package) " +
        "VALUES(@Name,@Password,@Email,@Gender,@Age,@Package); " +
        "SELECT SCOPE_IDENTITY();",con);

            cmd.Parameters.AddWithValue("@Name", txtSingUpName.Text);
            cmd.Parameters.AddWithValue("@Password", txtSingUpPassword.Text);
            cmd.Parameters.AddWithValue("@Email", txtSingUpEmail.Text);
            cmd.Parameters.AddWithValue("@Gender", gender);
            cmd.Parameters.AddWithValue("@Age", int.Parse(txtSingUpAge.Text));
            cmd.Parameters.AddWithValue("@Package", txtSingUpPackage.Text);
            cmd.ExecuteNonQuery();
            object newId = cmd.ExecuteScalar();
            int userId = Convert.ToInt32(newId);
            con.Close();
            txtSingUpUserId.Text = userId.ToString();
           MessageBox.Show("Registration successful. Your UserID is: " + userId);


            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void txtSingUpUserId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
