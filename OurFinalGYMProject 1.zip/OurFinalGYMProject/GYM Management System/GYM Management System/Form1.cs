﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace GYM_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.BackColor=Color.FromArgb(100, 0, 0, 0);


        }

        private void btnSingUp_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
         
            if (checkBox1.Checked)
            {
                txtLoginPasswrod.UseSystemPasswordChar=false;
            }
            else
            {
                txtLoginPasswrod.UseSystemPasswordChar=true;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {



            // ---------- Admin Login ----------
            if (txtLoginUserId.Text == "admin" && txtLoginPasswrod.Text == "1234")
            {
                MessageBox.Show("Admin Login Successful");
                Form3 f3 = new Form3();
                f3.Show();
                this.Hide();
                return;
            }
            DBConnection db = new DBConnection();
            SqlConnection con = db.GetConnection();

            try
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT * FROM Members WHERE UserID=@UserID AND Password=@Password",
                    con
                );

                da.SelectCommand.Parameters.AddWithValue("@UserID", txtLoginUserId.Text);
                da.SelectCommand.Parameters.AddWithValue("@Password", txtLoginPasswrod.Text);

                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    Form4 f4 = new Form4();
                    f4.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show(
                        "User ID or Password is incorrect",
                        "Login Failed",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error occurred");
            }
            finally
            {
                con.Close();
            }



        }
    }
}
