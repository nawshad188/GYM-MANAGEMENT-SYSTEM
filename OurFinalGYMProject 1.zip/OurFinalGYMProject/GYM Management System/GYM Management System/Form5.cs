﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM_Management_System
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();

        }



        public Form5(string package)
        {
            InitializeComponent();
            txtPaymentPackage.Text = package;
            txtPaymentPackage.ReadOnly = true;
        }

        private void txtpaymentAmount_TextChanged(object sender, EventArgs e)
        {

        }


        private void btnProceed_Click(object sender, EventArgs e)
        { 
            if (string.IsNullOrWhiteSpace(txtPaymentAmount.Text))
            {
                MessageBox.Show("Invalid Amount");
                return;
            }

            
            if (radioCash.Checked && radioCreditCard.Checked)
            {
                MessageBox.Show("Invalid Method: Select only one");
                return;
            }

            if (!radioCash.Checked && !radioCreditCard.Checked)
            {
                MessageBox.Show("Invalid Method: Please select a payment method");
                return;
            }

           
            string method = radioCash.Checked ? "Cash" : "Credit Card";

           
            MessageBox.Show($"Payment Successful via {method}!");
        }
    }

}

    